const DATA_PATH = './data/projects.json';
const PASS = 'Bong';
let projects = [];

const state = {
  z: 100,
  repo: JSON.parse(localStorage.getItem('portfolio_repo') || '{"owner":"","repo":"","branch":"main","token":""}')
};

function nowClock() {
  const d = new Date();
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
setInterval(() => document.getElementById('clock').textContent = nowClock(), 1000);
document.getElementById('clock').textContent = nowClock();

async function loadProjects() {
  const local = localStorage.getItem('portfolio_projects_override');
  if (local) {
    projects = JSON.parse(local);
    return;
  }
  const res = await fetch(DATA_PATH);
  projects = await res.json();
}

function iconEl(label, glyph = '📁', onOpen) {
  const btn = document.createElement('button');
  btn.className = 'desktop-icon';
  btn.innerHTML = `<div class="icon-glyph">${glyph}</div><div class="icon-label">${label}</div>`;
  btn.addEventListener('dblclick', onOpen);
  btn.addEventListener('click', () => btn.focus());
  return btn;
}

function openWindow(title, html) {
  const t = document.getElementById('window-template').content.cloneNode(true);
  const w = t.querySelector('.win-window');
  w.style.top = `${80 + Math.random() * 140}px`;
  w.style.left = `${120 + Math.random() * 240}px`;
  w.style.zIndex = ++state.z;
  w.querySelector('.win-title').textContent = title;
  w.querySelector('.win-body').innerHTML = html;
  w.querySelector('.win-close').onclick = () => w.remove();
  enableDrag(w);
  document.body.appendChild(w);
  return w;
}

function enableDrag(win) {
  const handle = win.querySelector('.drag-handle');
  let dragging = false, ox = 0, oy = 0;
  handle.addEventListener('mousedown', (e) => {
    dragging = true;
    ox = e.clientX - win.offsetLeft;
    oy = e.clientY - win.offsetTop;
    win.style.zIndex = ++state.z;
  });
  window.addEventListener('mousemove', (e) => {
    if (!dragging) return;
    win.style.left = `${Math.max(0, e.clientX - ox)}px`;
    win.style.top = `${Math.max(0, e.clientY - oy)}px`;
  });
  window.addEventListener('mouseup', () => dragging = false);
}

function projectWindow(p) {
  openWindow(p.name, `
    <h3>${p.name}</h3>
    <p><b>Brand:</b> ${p.brand}</p>
    <p><b>Role:</b> ${p.role}</p>
    <p><b>Year:</b> ${p.year}</p>
    <p>${p.description}</p>
  `);
}

function openTaskManager() {
  const pass = prompt('Task Manager password');
  if (pass !== PASS) return alert('Access denied.');

  const w = openWindow('Task Manager', `
    <p class="note">XP-style CMS. Every edit must be pushed to GitHub to survive refresh across devices.</p>
    <div class="settings">
      <label>Owner <input id="repoOwner" placeholder="github-username"></label>
      <label>Repo <input id="repoName" placeholder="portfolio-site"></label>
      <label>Branch <input id="repoBranch" placeholder="main"></label>
      <label>GitHub Token <input id="repoToken" placeholder="ghp_..." type="password"></label>
    </div>
    <div class="pm-toolbar">
      <button id="addRow">+ Add Project</button>
      <button id="saveLocal">Save Local</button>
      <button id="pullRepo">Pull From Repo</button>
      <button id="pushRepo">Push To Repo</button>
    </div>
    <div id="pmRows"></div>
    <p class="note">Schema: Project Name, Brand, Role, Year, Description.</p>
  `);

  const body = w.querySelector('.win-body');
  const rows = body.querySelector('#pmRows');

  body.querySelector('#repoOwner').value = state.repo.owner || '';
  body.querySelector('#repoName').value = state.repo.repo || '';
  body.querySelector('#repoBranch').value = state.repo.branch || 'main';
  body.querySelector('#repoToken').value = state.repo.token || '';

  const renderRows = () => {
    rows.innerHTML = '';
    projects.forEach((p, idx) => {
      const row = document.createElement('div');
      row.className = 'pm-row';
      row.innerHTML = `
        <input data-k="name" value="${escapeHtml(p.name || '')}" placeholder="Project Name">
        <input data-k="brand" value="${escapeHtml(p.brand || '')}" placeholder="Brand">
        <input data-k="role" value="${escapeHtml(p.role || '')}" placeholder="Role">
        <input data-k="year" value="${escapeHtml(p.year || '')}" placeholder="Year">
        <textarea data-k="description" placeholder="Description">${escapeHtml(p.description || '')}</textarea>
        <button data-del="${idx}">✕</button>`;
      row.querySelectorAll('input,textarea').forEach(el => {
        el.addEventListener('input', () => {
          const k = el.dataset.k;
          projects[idx][k] = el.value;
          projects[idx].icon = projects[idx].icon || '📁';
        });
      });
      row.querySelector('button').onclick = () => {
        projects.splice(idx, 1);
        renderRows();
      };
      rows.appendChild(row);
    });
  };

  body.querySelector('#addRow').onclick = () => {
    projects.push({ name: 'New Project', brand: '', role: '', year: '', description: '', icon: '📁' });
    renderRows();
  };

  body.querySelector('#saveLocal').onclick = () => {
    persistRepoSettings(body);
    localStorage.setItem('portfolio_projects_override', JSON.stringify(projects, null, 2));
    refreshDesktop();
    alert('Saved locally.');
  };

  body.querySelector('#pullRepo').onclick = async () => {
    persistRepoSettings(body);
    try {
      const remote = await fetchRepoProjects();
      projects = remote;
      localStorage.setItem('portfolio_projects_override', JSON.stringify(projects));
      renderRows();
      refreshDesktop();
      alert('Pulled from repo.');
    } catch (e) {
      alert(`Pull failed: ${e.message}`);
    }
  };

  body.querySelector('#pushRepo').onclick = async () => {
    persistRepoSettings(body);
    try {
      await pushRepoProjects(projects);
      localStorage.setItem('portfolio_projects_override', JSON.stringify(projects));
      refreshDesktop();
      alert('Pushed to repo and saved locally.');
    } catch (e) {
      alert(`Push failed: ${e.message}`);
    }
  };

  renderRows();
}

function persistRepoSettings(body) {
  state.repo = {
    owner: body.querySelector('#repoOwner').value.trim(),
    repo: body.querySelector('#repoName').value.trim(),
    branch: body.querySelector('#repoBranch').value.trim() || 'main',
    token: body.querySelector('#repoToken').value.trim()
  };
  localStorage.setItem('portfolio_repo', JSON.stringify(state.repo));
}

async function fetchRepoProjects() {
  const { owner, repo, branch, token } = state.repo;
  if (!owner || !repo || !token) throw new Error('Owner/repo/token required');
  const url = `https://api.github.com/repos/${owner}/${repo}/contents/data/projects.json?ref=${encodeURIComponent(branch)}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github+json' }});
  if (!res.ok) throw new Error(`${res.status} ${await res.text()}`);
  const data = await res.json();
  return JSON.parse(atob(data.content.replace(/\n/g, '')));
}

async function pushRepoProjects(payload) {
  const { owner, repo, branch, token } = state.repo;
  if (!owner || !repo || !token) throw new Error('Owner/repo/token required');
  const path = 'data/projects.json';
  const getUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${path}?ref=${encodeURIComponent(branch)}`;
  const getRes = await fetch(getUrl, { headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github+json' }});
  let sha;
  if (getRes.ok) {
    const cur = await getRes.json();
    sha = cur.sha;
  }
  const putRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${path}`, {
    method: 'PUT',
    headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github+json', 'Content-Type': 'application/json' },
    body: JSON.stringify({
      message: `cms: update projects ${new Date().toISOString()}`,
      content: btoa(unescape(encodeURIComponent(JSON.stringify(payload, null, 2)))),
      branch,
      sha
    })
  });
  if (!putRes.ok) throw new Error(`${putRes.status} ${await putRes.text()}`);
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}

function refreshDesktop() {
  const grid = document.getElementById('icon-grid');
  grid.innerHTML = '';

  projects.forEach(p => grid.appendChild(iconEl(p.name, p.icon || '📁', () => projectWindow(p))));
  grid.appendChild(iconEl('Task Manager', '🛠', openTaskManager));
}

(async function init() {
  await loadProjects();
  refreshDesktop();
})();